import React from 'react'

const Footer = () => {
  return (
    <>
        <p className="footer">©MKDO (MIT License 2023)</p>
    </>
  )
}

export default Footer